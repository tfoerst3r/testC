""" Entrypoint for CLI and python -m cr_cli """

from .cli import app

if __name__ == "__main__":
    app()
